<!DOCTYPE html>
<html>
<head>
    <title>About Me</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <h1>My Curriculum Vitae</h1>
    <h2>Personal Information</h2>
    <p><b>Name:</b> Mitchie C. Baunsit</p>
    <p><b>Address:</b> Opao, Cabahug Street Mandaue City</p>
    <p><b>Email:</b> mcwong1737@gmail.com</p>
    <p><b>GitHub:</b> https://github.com/mitcchhh</p>

    <h2>Educational Background</h2>
    <ul>
        <li>Elementary: Opao Elementary School</li>
        <li>High School: University of Cebu Lapu-lapu and Mandaue</li>
        <li>College: University of Cebu Lapu-lapu and Mandaue</li>
    </ul>

    <h2>Skills</h2>
    <ul>
        <li>PHP / Laravel</li>
        <li>HTML / CSS / JavaScript</li>
        <li>SQL Server</li>
        <li>GitHub</li>
    </ul>

    <h2>Interest</h2>
    <ul>
        <li>sketching</li>
        <li>Music</li>
        <li>Sleeping</li>
    </ul>

    <p><a href="/">Home</a> | <a href="/gallery">Gallery</a></p>
</body>
</html>

