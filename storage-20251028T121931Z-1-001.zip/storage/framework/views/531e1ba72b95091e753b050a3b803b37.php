<!DOCTYPE html>
<html>
<head>
    <title>My Gallery</title>
    <link rel="stylesheet" href="<?php echo e(asset('style.css')); ?>">
</head>
<body>
    <h1>Photo Gallery</h1>
    <p>Here are 15 photos of me:</p>

    <div class="gallery-grid">
        <?php for($i = 1; $i <= 15; $i++): ?>
            <img src="<?php echo e(asset('photos/b' . $i . '.jpg')); ?>" alt="Photo <?php echo e($i); ?>">
        <?php endfor; ?>
    </div>

    <p><a href="/">Home</a> | <a href="/about">About Me</a></p>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\BWebsite\resources\views/gallery.blade.php ENDPATH**/ ?>